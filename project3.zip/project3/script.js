// Game variables
let currentPlayer = 'X';
let board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
];

// Function to handle a cell click
function cellClicked(row, col) {
    if (board[row][col] === '') {
        board[row][col] = currentPlayer;
        let cell = document.getElementById('board').children[row * 3 + col];
        cell.innerText = currentPlayer;
        cell.classList.add('played'); // Add class for styling
        cell.classList.add(currentPlayer); // Add class based on player (X or O)
        
        if (checkWin(currentPlayer)) {
            highlightWinningCells(); // Highlight winning cells
            setTimeout(() => {
                alert(currentPlayer + ' wins!');
                resetBoard();
            }, 500); // Delay alert to show winning cells first
        } else if (checkDraw()) {
            alert('It\'s a draw!');
            resetBoard();
        } else {
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        }
    }
}

// Function to check for a win
function checkWin(player) {
    // Check rows, columns, and diagonals
    for (let i = 0; i < 3; i++) {
        if (board[i][0] === player && board[i][1] === player && board[i][2] === player) return true; // Row win
        if (board[0][i] === player && board[1][i] === player && board[2][i] === player) return true; // Column win
    }
    if (board[0][0] === player && board[1][1] === player && board[2][2] === player) return true; // Diagonal win
    if (board[0][2] === player && board[1][1] === player && board[2][0] === player) return true; // Diagonal win
    return false;
}

// Function to check for a draw
function checkDraw() {
    for (let row of board) {
        for (let cell of row) {
            if (cell === '') return false; // There is an empty cell, game is not a draw
        }
    }
    return true; // All cells are filled, it's a draw
}

// Function to reset the board
function resetBoard() {
    // Reload the page to reset the game
    location.reload();
}

// Function to highlight winning cells
function highlightWinningCells() {
    // Determine the winning combination
    for (let combination of WINNING_COMBINATIONS) {
        let [a, b, c] = combination;
        if (board[a[0]][a[1]] === currentPlayer &&
            board[b[0]][b[1]] === currentPlayer &&
            board[c[0]][c[1]] === currentPlayer) {
                // Highlight cells
                let cells = [
                    document.getElementById('board').children[a[0] * 3 + a[1]],
                    document.getElementById('board').children[b[0] * 3 + b[1]],
                    document.getElementById('board').children[c[0] * 3 + c[1]]
                ];
                cells.forEach(cell => {
                    cell.classList.add('winning-cell');
                });
                break;
        }
    }
}

// Winning combinations
const WINNING_COMBINATIONS = [
    [[0, 0], [0, 1], [0, 2]], // Top row
    [[1, 0], [1, 1], [1, 2]], // Middle row
    [[2, 0], [2, 1], [2, 2]], // Bottom row
    [[0, 0], [1, 0], [2, 0]], // Left column
    [[0, 1], [1, 1], [2, 1]], // Middle column
    [[0, 2], [1, 2], [2, 2]], // Right column
    [[0, 0], [1, 1], [2, 2]], // Top-left to bottom-right diagonal
    [[0, 2], [1, 1], [2, 0]]  // Top-right to bottom-left diagonal
];
